<?php

namespace App\Policies;

use Spatie\Csp\Directive;
use Spatie\Csp\Keyword;
use Spatie\Csp\Policies\Basic;
use Spatie\Csp\Policies\Policy;
use Spatie\Csp\Value;

class CspPolicy extends Basic
{
    public function configure()
    {
    }
}
