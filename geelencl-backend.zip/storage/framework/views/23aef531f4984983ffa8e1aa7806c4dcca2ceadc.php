<?php $__env->startSection('content'); ?>

<?php if(Session('success')): ?>

<div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
    <div class="alert-icon"><i class="flaticon-folder-1"></i></div>
    <div class="alert-text"><?php echo e(Session('success'), false); ?></div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="ki ki-close"></i></span>
        </button>
    </div>
</div>

 <?php endif; ?>

 <?php if($provider->statusInformation == 'Enviado'): ?>

<div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
    <div class="alert-icon"><i class="flaticon-paper-plane"></i></div>
    <div class="alert-text">Formulario enviado correctamente</div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="ki ki-close"></i></span>
        </button>
    </div>
</div>

 <?php endif; ?>
<div class="card card-custom">
    <div class="card-header flex-wrap py-5">
        <div class="card-title">
               
            <h3 class="card-label">Formulario de proveedor</h3>
        </div>
        <div class="card-toolbar">
          <?php if($provider->statusInformation == 'Guardado'): ?>
            <button onclick="saveForm()" name= "action" value="Enviar" class="btn btn-info p-4 m-2">Enviar</button>
            
          <?php endif; ?>
          <?php if($provider->statusInformation == 'Calificado'): ?>
          <h3><b>Calificación: </b><?php echo e($provider->qualification, false); ?></h3> 
          <?php endif; ?>
          <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('saveProviderCompany'), false); ?>" id="form_provider_qualification" name="form_provider_qualification">
                    <?php echo csrf_field(); ?>
                    <?php if($provider->statusInformation == 'Guardado' || $provider->statusInformation == 'Creado'): ?>
          <button type="submit" name ="action" value="Guardar" class="btn btn-primary mr-2 p-4">Guardar</button>
            
          <?php endif; ?>
        </div>
    </div>
    <hr>
    <h4 class="ml-8">Complete la información</h4>
    <div id="accordion">
        <div class="card">    

            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-header" id="heading<?php echo e($section->id, false); ?>">
                  <h5 class="mb-0">
                    <button type="button" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse<?php echo e($section->id, false); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($section->id, false); ?>">
                        <i class="fas fa-angle-down"></i><?php echo e($section->name, false); ?>

                    </button>
                  </h5>
                </div>
                <div id="collapse<?php echo e($section->id, false); ?>" class="collapse" aria-labelledby="heading<?php echo e($section->id, false); ?>" data-parent="#accordion">
                  <div class="card-body">
                    <div class="form-row">
                        <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="form-group col-md-10">
                            
                            <h5><pre style="font-family: Poppins"> <?php echo e($question->order, false); ?> .- <?php echo e($question->question, false); ?></pre></h5>

                            <br>
                            <?php
                            $count = 1;
                            ?>
                            
                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                                <?php if($question->type_question == 'MULTIPLE'): ?>
                                    <?php
                                    $answerSaved = false;
                                    ?>
                                    <?php $__currentLoopData = $questionSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($saved->preguntas_id == $question->id && $saved->respuestas_id == $answer->id ): ?>
                                        <?php
                                        $answerSaved = true; 
                                        ?>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline<?php echo e($count.$question->id, false); ?>" name="answerQuestion-<?php echo e($question->id, false); ?>" value="<?php echo e($answer->id, false); ?>" checked = <?php echo e($saved->value, false); ?> class="custom-control-input" >
                                            <label class="custom-control-label" for="customRadioInline<?php echo e($count.$question->id, false); ?>"><?php echo e($answer->answer, false); ?></label>
                                        </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$answerSaved): ?>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="customRadioInline<?php echo e($count.$question->id, false); ?>" name="answerQuestion-<?php echo e($question->id, false); ?>" value="<?php echo e($answer->id, false); ?>"   class="custom-control-input" >
                                        <label class="custom-control-label" for="customRadioInline<?php echo e($count.$question->id, false); ?>"><?php echo e($answer->answer, false); ?></label>
                                    </div>
                                    <?php endif; ?>
                                
                                <?php
                                    $count = $count + 1;
                                ?>
                                <?php endif; ?>   
                                <?php if($question->type_question == 'ABIERTA'): ?>
                                    <?php
                                        $answerSaved = false;
                                    ?>
                                    <?php $__currentLoopData = $questionSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($saved->preguntas_id == $question->id && $saved->respuestas_id == $answer->id ): ?>
                                        <?php
                                        $answerSaved = true; 
                                        ?>
                                        <textarea rows="4" class="col-md-12" placeholder="Ingrese su respuesta" name="answerQuestion-<?php echo e($question->id, false); ?>-<?php echo e($answer->id, false); ?>"><?php echo e($saved->value, false); ?></textarea>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$answerSaved): ?>
                                    <textarea rows="4" class="col-md-12" placeholder="Ingrese su respuesta" name="answerQuestion-<?php echo e($question->id, false); ?>-<?php echo e($answer->id, false); ?>"></textarea>
                                    <?php endif; ?>
                                <?php endif; ?>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                          </div>
                          <div class="col-md-10">
                            <?php
                                        $answerSaved = false;
                                    ?>
                                    <?php $__currentLoopData = $questionSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($saved->preguntas_id == $question->id && $saved->directory != null ): ?>
                                        <?php
                                        $answerSaved = true; 
                                        ?>
                                        <p>Medio de verificación guardado para visualizar presiona aquí <a href="<?php echo e($saved->directory, false); ?>" target="_blank">Ver documento</a></p>
                                         <br>
                                         <p>Si deseas reemplazar el archivo, carga nuevamente tu medio de verificación 🡳</p>
                                        <input type="hidden" name="existFile-<?php echo e($question->id, false); ?>" value="<?php echo e($saved->directory, false); ?>">

                                        <?php endif; ?>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($question->document == 'SI'): ?>

                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFileLang" lang="es" name="fileQuestion-<?php echo e($question->id, false); ?>"  >
                                <label class="custom-file-label" for="customFileLang">Seleccionar archivo de verificación</label>
                            </div>
                            <?php endif; ?>
                                              
                                    
                            <br> <br>
                            
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                    </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>

        <input id="action_save" type="hidden" value="<?php echo e(route("saveProviderCompany"), false); ?>"/>
</div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/companyProviders/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/providersCompany/index.blade.php ENDPATH**/ ?>