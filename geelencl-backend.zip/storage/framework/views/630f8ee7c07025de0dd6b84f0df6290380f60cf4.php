<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
       .pagenum:before {
    content: counter(page);
}
      </style>
</head>

<body>
    <div style="text-align: center;">
        <text style="font-size: 25px; font-family: Arial, Helvetica, sans-serif">Constancia de auditoria</text><br>
        <text style="font-size: 18px; font-family: Arial, Helvetica, sans-serif; margin-top: 25px;">Nº <?php echo e($provider->id, false); ?>/<?php echo e($anio, false); ?></text>
    </div>
    
    <div style="margin-top: 25px;font-size: 18px; font-family: Arial, Helvetica, sans-serif; margin-top: 25px;">
        <text>GELEENCL. por solicitud de <?php echo e($provider->company->comercial_name, false); ?>, ha llevado a cabo el proceso de auditoria al proveedor:</text>
    </div>
    <div style="text-align: center; margin-top: 20px;">
        <text style="font-size: 20px; font-family: Arial, Helvetica, sans-serif;"><?php echo e($provider->legal_name, false); ?></text>
    </div>
    <div style="text-align: center; margin-top: 20px;">
        <text style="font-size: 15px; font-family: Arial, Helvetica, sans-serif;">RUC: <?php echo e($provider->ruc, false); ?></text><br>
        <text style="font-size: 15px; font-family: Arial, Helvetica, sans-serif;"><?php echo e($provider->typeProvider->name, false); ?></text><br>
        <text style="font-size: 15px; font-family: Arial, Helvetica, sans-serif;">Quito - Ecuador</text>
    </div>
    <div style="text-align: center" style="margin-left: 10%; font-family: Arial, Helvetica, sans-serif; margin-top: 20px">
    <table style="width: 90%; border-collapse: collapse;"> 
        <thead> 
            <tr style="background-color: #4682B4; 
            color: #ffffff; 
            text-align: center;  padding: 12px 15px;
            ">
                <th style=" border: 1px solid black;">Aspecto</th>
                <th style=" border: 1px solid black;">Ponderado</th> 
                <th style=" border: 1px solid black;">Puntaje Parcial</th> 
                <th style=" border: 1px solid black;">Valor obtenido</th> 
            </tr> 
        </thead> 
        <tbody> 
           
            <?php $__currentLoopData = $sectiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> 
                <td style=" border: 1px solid black;"><?php echo e($section['section'], false); ?></td> 
                <td style=" border: 1px solid black; text-align: center;"><?php echo e($section['puntaje'], false); ?></td> 
                <td style=" border: 1px solid black; text-align: center;"><?php echo e($section['parcial'], false); ?></td> 
                <td style=" border: 1px solid black; text-align: center;"><?php echo e($section['valor'], false); ?></td> 
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
            
        </tbody> 
    </table>
    </div>
    <div style="text-align: center" style="margin-left: 20%; font-family: Arial, Helvetica, sans-serif; margin-top: 20px">
        <table style="width: 80%; border-collapse: collapse;">
            <tr style="text-align: center;">
                <td style=" border: 1px solid black;">Total</td>
                <td style=" border: 1px solid black;"><?php echo e($provider->qualification, false); ?></td>
               
                <td style=" border: 1px solid black;">Nivel</td>
                <?php if($provider->qualification >= 90): ?>
                <td style=" border: 1px solid black;">A</td>
                <?php endif; ?>
                <?php if($provider->qualification < 90 && $provider->qualification >= 70): ?>
                <td style=" border: 1px solid black;">B</td>
                <?php endif; ?>
                <?php if($provider->qualification < 70): ?>
                <td style=" border: 1px solid black;">C</td>
                <?php endif; ?>
                
            </tr>
        </table>
    </div>
    <div style="margin-top: 15px;">
        <div style="float: left; width: 40%;">
            <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Período de Validez Del: <?php echo e($fecha_actual, false); ?> al <?php echo e($fecha_anio, false); ?> </text><br>
            <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Emisión 2- REN</text><br>
        </div>
        <div style="margin-left: 60%; width: 50%;">
            <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Autorizado por </text><br>
            <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('uploads' . $url))), false); ?>"><br>
            <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;"><?php echo e($datosFirma->nombres, false); ?></text><br>
            <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;"><?php echo e($datosFirma->cargo, false); ?></text><br>
            <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;">GELEENCL</text>
        </div>
    </div>
    <div style="margin-top: 15px; font-family: Arial, Helvetica, sans-serif;">
    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style=" border: 1px solid black;">CONDICIONES DE EMISIÓN</td>
        </tr>
        <tr>
            <td style=" border: 1px solid black;">
                <text>
                    1. Información consignada en la presente constancia es un resumen del informe de resultados y fiel reflejo de nuestros hallazgos en el lugar y fecha de la auditoria.
                </text><br>
                <text>
                    2. El alcance de la presente constancia se extiende exclusivamente a la actividad evaluada. Esta auditor a y sus resultados no constituyen
                    un vinculo contractual con <?php echo e($provider->company->comercial_name, false); ?>    
                </text><br>
                <text>
                    3. La responsabllldad de nuestra empresa se extiende a garantizar únicamente que el proveedor ha sido auditado de acuedo al procedimiento establecido por <?php echo e($provider->company->comercial_name, false); ?>. GELEENCL. no asume responsabllldad alguna si elproveedor ralla en algún producto o servicio.que fue objeto de la auditoria
  
                </text>
                </td>
        </tr>

    </table>
    </div>
    <div style="margin-top: 10px;">
        <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;">La calificación aprobatoria es de 75%.</text>
    </div>
    <div style="margin-top: 10px; text-align: center;">
        <text style="font-size: 12px; font-family: Arial, Helvetica, sans-serif;"><?php echo e($provider->codigo, false); ?></text>
    </div>
    
    <div style="margin-top: 15px; font-family: Arial, Helvetica, sans-serif;">
        <table style="width: 100%; border-collapse: collapse;">
            <tr style="text-align: center;">
                <td style=" border: 1px solid black;">La presente constancia reposa en la base de dalos de GELEENCL y los resultados están conforme a la auditoría solicitada por el cliente</td>
            </tr>
            <tr>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr style="text-align: center;">
                        <td style=" border: 1px solid black;">
                            CÓDIGO VERIFICADOR
                        </td>
                        <td style=" border: 1px solid black;">
                            ORDEN DE iNSPECCIÓN
                        </td>
                        <td style=" border: 1px solid black;">
                            FECHA PUBLICACIÓN
                        </td>
                        <td style=" border: 1px solid black;">
                            PÁGINA
                        </td>
                    </tr>
                    <tr style="text-align: center;">
                        <td style=" border: 1px solid black;">
                            SGSOl 520232850029671207202
                        </td>
                        <td style=" border: 1px solid black;">
                            OL28S-2967
                        </td>
                        <td style=" border: 1px solid black;">
                            <?php echo e($fecha_actual, false); ?>

                        </td>
                        <td style=" border: 1px solid black;">
                            <span class="pagenum"></span>

                        </td>
                    </tr>
                </table>
            </tr>
        
        </table>
        </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/companyProviders/reporte.blade.php ENDPATH**/ ?>