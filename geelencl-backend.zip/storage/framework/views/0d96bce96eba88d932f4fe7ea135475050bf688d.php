<?php $__env->startSection('content'); ?>
    <center><h1>No cuentas con acceso a esta página</h1></center>
<?php $__env->stopSection(); ?>


<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/denied.blade.php ENDPATH**/ ?>