<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Lista de proveedores',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'companyProviders_table',
    
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Finalizar Evaluación',
    'id'=>'test_modal',
    'size' => 'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'test_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_list" type="hidden" value="<?php echo e(route("getListDataCompanyProviders"), false); ?>"/>
    <input id="action_index_provider" type="hidden" value="<?php echo e(route("viewIndexInformationProvider"), false); ?>"/>
    <input id="action_generate_certificade" type="hidden" value="<?php echo e(route("generatePdf"), false); ?>"/>
    <input id="action_form_test" type="hidden" value="<?php echo e(route("getFormtest"), false); ?>"/>
    <input id="action_save_test" type="hidden" value="<?php echo e(route("saveTest"), false); ?>"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/companyProviders/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/companyProviders/index.blade.php ENDPATH**/ ?>