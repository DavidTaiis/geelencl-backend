<div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
    <!--begin::Container-->
    <div class="container d-flex flex-column flex-md-row align-items-center justify-content-between">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted font-weight-bold mr-2">2020©</span>
            <a href="http://keenthemes.com/metronic" target="_blank"
               class="text-dark-75 text-hover-primary"></a>
        </div>
        <!--end::Copyright-->
    </div>
    <!--end::Container-->
</div>
<?php /**PATH C:\xampp\htdocs\geleenc_backend\resources\views/layouts/partials2/footer.blade.php ENDPATH**/ ?>