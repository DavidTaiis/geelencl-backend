<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de Proveedores',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'provider_table',
    'action_buttons'=>[
        [
        'label'=>'Crear Proveedor',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newProvider()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear Proveedor',
    'id'=>'provider_modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'provider_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormProvider"), false); ?>"/>
    <input id="action_unique_name" type="hidden" value="<?php echo e(route("uniqueNameProvider"), false); ?>"/>
    <input id="action_save_provider" type="hidden" value="<?php echo e(route("saveProvider"), false); ?>"/>
    <input id="action_load_provider" type="hidden" value="<?php echo e(route("getListDataProvider"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/provider/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/provider/index.blade.php ENDPATH**/ ?>