<script src="<?php echo e(asset("nifty/plugins/pace/pace.min.js"), false); ?>"></script>

<!--jQuery [ REQUIRED ]-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" ></script>


<!--BootstrapJS [ RECOMMENDED ]-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js" ></script>

<script src="<?php echo e(asset('js/plugins/jquery-validation/jquery.validate.js'), false); ?>"></script>
<script src="<?php echo e(asset('js//plugins/jquery-validation/additional-methods.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/plugins/jquery-validation/localization/messages_es.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/plugins/jquery.blockUI.js'), false); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.27.0/moment.min.js" ></script>

<!--NiftyJS [ RECOMMENDED ]-->
<script src="<?php echo e(asset("nifty/js/nifty.min.js"), false); ?>"></script>

<script src="<?php echo e(asset('nifty/plugins/datatables/media/js/jquery.dataTables.js'), false); ?>"></script>
<script src="<?php echo e(asset('nifty/plugins/datatables/media/js/dataTables.bootstrap.js'), false); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" ></script>
<script src="<?php echo e(asset('nifty/plugins/select2/js/i18n/es.js'), false); ?>"></script>
<script src="<?php echo e(asset('nifty/plugins/bootbox/bootbox.min.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/plugins/bootstrap-toggle/js/bootstrap-toggle.js'), false); ?>"></script>
<script src="<?php echo e(asset('js/plugins/jquery-mask/jquery.mask.min.js'), false); ?>"></script>

<script src="<?php echo e(asset('js/plugins/daterangepicker/daterangepicker.js'), false); ?>"></script>
<script src="<?php echo e(asset("nifty/plugins/summernote/summernote.min.js"), false); ?>"></script>




<script src="<?php echo e(asset("js/common_code.js"), false); ?>"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0-rc.2/jquery-ui.js"></script>


<!-- jsDelivr :: Sortable :: Latest (https://www.jsdelivr.com/package/npm/sortablejs) -->

<!--=================================================-->

<?php echo $__env->yieldContent('additional-scripts'); ?>
<?php /**PATH C:\xampp\htdocs\geleenc_backend\resources\views/layouts/partials/scripts.blade.php ENDPATH**/ ?>