<?php $__env->startSection('content'); ?>
<?php                         
$abierta = false;
$puntaje = 0;
?>
<div class="card card-custom">
    <div class="card-header flex-wrap py-5">
        <div class="card-title">
        
            <h3 class="card-label">Formulario de proveedor <?php echo e($provider->legal_name, false); ?></h3>
        </div>
        <div class="card-toolbar">
          <span class="badge badge-secondary py-4 px-4 mr-3">Estado: </span>
            <?php if($provider->statusInformation == 'Guardado'): ?>
            <span class="badge badge-primary py-4 px-4"><?php echo e($provider->statusInformation, false); ?></span>
            
            <?php endif; ?>
            <?php if($provider->statusInformation == 'Enviado'): ?>
            <span class="badge badge-primary py-4 px-4"><?php echo e($provider->statusInformation, false); ?></span>
            
            <?php endif; ?>
            <?php if($provider->statusInformation == 'Calificado'): ?>
            <span class="badge badge-danger py-4 px-4"><?php echo e($provider->statusInformation, false); ?> &nbsp; <?php echo e($provider->qualification, false); ?></span>
            
            <?php endif; ?>
            <?php if($provider->statusInformation == 'Creado'): ?>
            <span class="badge badge-info py-4 px-4">Creado</span>
           
    
            <?php endif; ?>
        </div>
    </div>
    <hr>
    <h4 class="ml-8">Califica de acuerdo a las respuestas ingresadas</h4>
    <div id="accordion">
        <form method="POST" action = "<?php echo e(route('qualificationProvider'), false); ?>" id="calification_form">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-header" id="heading<?php echo e($section->id, false); ?>">
                  <h5 class="mb-0">
                    <button type="button" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse<?php echo e($section->id, false); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($section->id, false); ?>">
                        <i class="fas fa-angle-down"></i><?php echo e($section->name, false); ?>

                    </button>
                  </h5>
                </div>
                <div id="collapse<?php echo e($section->id, false); ?>" class="collapse" aria-labelledby="heading<?php echo e($section->id, false); ?>" data-parent="#accordion">
                  <div class="card-body">
                    <div class="form-row">
                        <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="form-group col-md-10">
                        <?php
                        $isContainer = false;
                          if (strpos($question->question, ':') !== false) {
                                    $isContainer = true;
                                }
                        ?>
                        <?php if($isContainer): ?>
                        <h5><pre style="font-family: Poppins"> <?php echo e($question->order, false); ?> .- <?php echo e($question->question, false); ?></pre></h5>

                        <?php endif; ?>
                        <?php if(!$isContainer): ?>
                        <h5> <?php echo e($question->order, false); ?> .- <?php echo e($question->question, false); ?></h5>
                        <?php endif; ?>
                          <br>
                            <?php
                            $count = 1;
                            ?>
                            
                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                                <?php if($question->type_question == 'MULTIPLE'): ?>
                              

                                    <?php
                                    $answerSaved = false;
                                    ?>
                                    <?php $__currentLoopData = $questionSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($saved->preguntas_id == $question->id && $saved->respuestas_id == $answer->id ): ?>
                                        <?php
                                        $answerSaved = true; 
                                        $puntaje = $answer->puntaje;
                                        $abierta = false;
                                        ?>
                                        <div class="custom-control custom-radio custom-control-inline">
                                            <input type="radio" id="customRadioInline<?php echo e($count.$question->id, false); ?>" name="answerQuestion-<?php echo e($question->id, false); ?>" value="<?php echo e($answer->id, false); ?>" checked = <?php echo e($saved->value, false); ?> class="custom-control-input" disabled>
                                            <label class="custom-control-label" for="customRadioInline<?php echo e($count.$question->id, false); ?>"><?php echo e($answer->answer, false); ?></label>
                                        </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$answerSaved): ?>
                                    <div class="custom-control custom-radio custom-control-inline">
                                        <input type="radio" id="customRadioInline<?php echo e($count.$question->id, false); ?>" name="answerQuestion-<?php echo e($question->id, false); ?>" value="<?php echo e($answer->id, false); ?>"   class="custom-control-input" >
                                        <label class="custom-control-label" for="customRadioInline<?php echo e($count.$question->id, false); ?>"><?php echo e($answer->answer, false); ?></label>
                                    </div>
                                    <?php endif; ?>
                                
                                <?php
                                    $count = $count + 1;
                                ?>
                                <?php endif; ?>   
                                <?php if($question->type_question == 'ABIERTA'): ?>
                                    <?php
                                        $answerSaved = false;
                                       
                                    ?>
                                    <?php $__currentLoopData = $questionSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <?php if($saved->preguntas_id == $question->id && $saved->respuestas_id == $answer->id ): ?>
                                        <?php
                                        $answerSaved = true; 
                                        $abierta = true;
                                        $puntaje = $answer->puntaje;
                                        ?>
                                        <?php if($saved->qualification != null): ?>
                                        <?php
                                        $puntaje = $saved->qualification;
                                        ?>
                                        <?php endif; ?>
                                        <textarea rows="4" class="col-md-12" placeholder="Ingrese su respuesta" name="answerQuestion-<?php echo e($question->id, false); ?>-<?php echo e($answer->id, false); ?>" readonly><?php echo e($saved->value, false); ?></textarea>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(!$answerSaved): ?>
                                    <textarea rows="4" class="col-md-12" placeholder="Ingrese su respuesta" name="answerQuestion-<?php echo e($question->id, false); ?>-<?php echo e($answer->id, false); ?>" readonly></textarea>
                                    <?php endif; ?>
                                <?php endif; ?>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                          </div>
                          
                          <div class="col-md-10">
                            <?php
                                        $answerSaved = false;
                                    ?>
                                    <?php $__currentLoopData = $questionSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($saved->preguntas_id == $question->id && $saved->directory != null ): ?>
                                        <?php
                                        $answerSaved = true; 
                                        ?>
                                        <p>Medio de verificación guardado para visualizar presiona aquí <a href="<?php echo e(config('constants.urlDirection'), false); ?><?php echo e($saved->directory, false); ?>" target="_blank">Ver documento</a></p>
                                         <br>
                                                            
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    <?php if(!$answerSaved): ?>
                                    <p>Ningún documento ha sido subido aún.</p>
                                    <?php endif; ?> 
                                    <?php if($provider->statusInformation != 'Evaluado'): ?>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Calificación:</label>
                                        <div class="col-md-6">
                                            <?php if($abierta == true): ?>
                                          <input type="number" class="form-control" name="qualification-<?php echo e($section->id, false); ?>-<?php echo e($question->id, false); ?>" id="staticEmail" value=<?php echo e($puntaje, false); ?>>
                                            <?php else: ?>
                                          <input type="number" class="form-control" name="qualification-<?php echo e($section->id, false); ?>-<?php echo e($question->id, false); ?>" id="staticEmail" value=<?php echo e($puntaje, false); ?> readonly>

                                            <?php endif; ?>
                                        </div>
                                      </div>      
                                    <?php endif; ?>  
                                                    
                            <br>
                            
                        </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                    </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <input type="hidden" name = "providerId" value="<?php echo e($provider->id, false); ?>">
            </form>
            <?php if($provider->statusInformation != "Guardado" || $provider->statusInformation != "Creado" ): ?>
            <div style="text-align: right">
                <button class="btn mr-4 mt-2 px-8" style="background: green; color:white" type="submit" onclick="guardarDatos()"> Calificar </button></div>
            <?php endif; ?>
            
          

            
        
</div>
<input id="action_save" type="hidden" value="<?php echo e(route("qualificationProvider"), false); ?>"/>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/providersCompany/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/providersInformation/index.blade.php ENDPATH**/ ?>