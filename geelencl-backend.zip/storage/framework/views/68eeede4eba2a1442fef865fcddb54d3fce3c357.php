<?php $__env->startSection('content'); ?>
<?php if($company): ?>
<div class="bg-white " style="margin-top: 0px ; text-align: center; width:100% ; align-self: center; padding-bottom: 15px;">
    
      <br> 
      <div class="d-flex flex-column ">
    <label style="text-aling: center"><b>Secciones de la empresa</b> </label><br>
   <span><label><b>Nombre Legal:</b> </label>
    <label><?php echo e($company->comercial_name, false); ?> </label></span>
    <span><label><b>Nombre Comercial:</b> </label>
    <label><?php echo e($company->legal_name, false); ?> </label></span>
    <span><label><b>Estado :</b> </label>
      <?php if($company->status == 'ACTIVE'): ?>
      <label> Activo</label></span>
      <?php else: ?>
      <label>Inactivo </label></span>
      <?php endif; ?>
      </div> 
      <div  style="text-align: left; margin: 10px;">
        <a href="<?php echo e(route('indexViewCompany'), false); ?>" style = "margin-bottom: 15px;" target=""><span class="btn btn-secondary btn-left"><i class="fas fa-angle-double-left"></i> Atrás</span></a> </div>    
    </div> 
    <?php endif; ?>

    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de secciones',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'section_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newSection()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear sección',
    'id'=>'modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'section_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormSection", $company->id), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(route("saveSection"), false); ?>"/>
    <input id="action_list" type="hidden" value="<?php echo e(route("getListDataSection", $company->id), false); ?>"/>
    <input id="action_index_question" type="hidden" value="<?php echo e(route("viewIndexQuestion"), false); ?>"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/section/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/section/index.blade.php ENDPATH**/ ?>