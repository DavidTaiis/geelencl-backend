<!DOCTYPE html>
<html lang="en">
<!-- begin::Head -->
<?php echo $__env->make('layouts.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style  nonce="<?php echo e(csp_nonce(), false); ?>">
    .brand-icon-login {
        width: 150px;
    }
    .brand-title {
        text-align: center;
        width: 100%;
    }
</style>
<!-- end::Head -->
<!--TIPS-->
<!--You may remove all ID or Class names which contain "demo-", they are only used for demonstration. -->
<body>
<div id="container" class="cls-container">
    <!-- BACKGROUND IMAGE -->
    <!--===================================================-->
    <div id="bg-overlay"></div>

    <?php echo $__env->yieldContent('content'); ?>
    <!-- LOGIN FORM -->
    <!--===================================================-->

    <!--===================================================-->
</div>
<!--===================================================-->
<!-- END OF CONTAINER -->

</body>
</html>



<?php /**PATH C:\xampp\htdocs\geleenc_backend\resources\views/layouts/login.blade.php ENDPATH**/ ?>