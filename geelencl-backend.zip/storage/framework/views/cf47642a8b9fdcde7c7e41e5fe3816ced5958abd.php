<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de tipo de proveedor',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'typeProvider_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newTypeProvider()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear tipo de proveedor',
    'id'=>'modal',
    'size'=>'modal-md',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'typeProvider_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormTypeProvider"), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(route("saveTypeProvider"), false); ?>"/>
    <input id="action_list" type="hidden" value="<?php echo e(route("getListDataTypeProvider"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/typeProvider/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/typeProvider/index.blade.php ENDPATH**/ ?>