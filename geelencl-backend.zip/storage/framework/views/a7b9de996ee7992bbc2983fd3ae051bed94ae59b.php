<?php echo Form::model($testEnd, array('id' => 'test_form','class' => 'form-horizontal', 'method' => $method)); ?>

<?php echo Form::hidden('test_id', $testEnd->id_test,['id'=>'test_id']); ?>

<?php echo Form::hidden('id_proveedor', $idProveedor,['id'=>'id_proveedor']); ?>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <?php echo Form::label('comunication','* Se comunicó al cliente los resultados de evaluación:', array('class' => 'control-label col-md-12')); ?>

            <div class="col-md-12">
            <?php echo Form::select('comunication', array( 'SI' => 'SI', 'NO' => 'NO'),$testEnd->comunication,array('class' => 'form-control') ); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
        <?php echo Form::label('fecha','* Fecha:', array('class' => 'control-label col-md-12')); ?>

        <div class="col-md-12">
        <?php echo Form::date('date_end', $testEnd->date_end, array('class' => 'form-control', 'autocomplete' =>
                'off', 'placeholder' => '2023-12-05', 'maxlength' => '128')); ?>

        </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
        <?php echo Form::label('email','* Correo:', array('class' => 'control-label col-md-12')); ?>

        <div class="col-md-12">
        <?php echo Form::email('email', $testEnd->email, array('class' => 'form-control', 'autocomplete' =>
                'off', 'placeholder' => 'abc@abc.com', 'maxlength' => '128')); ?>

        </div>
        </div>
    </div>
    <div class="col-md-12">
    <div class="form-group">
            <?php echo Form::label('observation','* Observaciones:', array('class' => 'control-label col-md-12')); ?>

            <div class="col-md-12">
                <?php echo Form::textArea('observation', $testEnd->observation, array('class' => 'form-control', 'autocomplete' =>
                'off', 'rows' => 4)); ?>

            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/companyProviders/loads/_form.blade.php ENDPATH**/ ?>