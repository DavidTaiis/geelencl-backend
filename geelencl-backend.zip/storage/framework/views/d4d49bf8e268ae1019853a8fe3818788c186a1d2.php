<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de respuestas',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'answers_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newAnswers()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear respuesta',
    'id'=>'modal',
    'size'=>'modal-md',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'answers_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormAnswers"), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(route("saveAnswers"), false); ?>"/>
    <input id="action_list" type="hidden" value="<?php echo e(route("getListDataAnswers"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/answers/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/answers/index.blade.php ENDPATH**/ ?>