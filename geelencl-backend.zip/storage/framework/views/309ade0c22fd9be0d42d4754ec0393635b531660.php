<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de empresas',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'company_table',
    'action_buttons'=>[
        [
        'label'=>'Crear empresa',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newCompany()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear Empresa',
    'id'=>'company_modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'company_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormCompany"), false); ?>"/>
    <input id="action_unique_name" type="hidden" value="<?php echo e(route("uniqueNameCompany"), false); ?>"/>
    <input id="action_save_company" type="hidden" value="<?php echo e(route("saveCompany"), false); ?>"/>
    <input id="action_load_company" type="hidden" value="<?php echo e(route("getListDataCompany"), false); ?>"/>
    <input id="action_index_sections" type="hidden" value="<?php echo e(route("viewIndexSection"), false); ?>"/> 

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/company/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/company/index.blade.php ENDPATH**/ ?>