<head>
    <base href="">
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name', 'Laravel'), false); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <meta name="description" content="Updates and statistics" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="canonical" href="https://keenthemes.com/metronic" />
    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
    <!--end::Fonts-->
    <!--begin::Page Custom Styles(used by this page)-->
    <link href="<?php echo e(asset("theme/metronic/css/pages/login/login-2.css"), false); ?>" rel="stylesheet" type="text/css" />
    <!--end::Page Custom Styles-->
    <!--begin::Page Vendors Styles(used by this page)-->
    <link href="<?php echo e(asset("theme/metronic/plugins/custom/datatables/datatables.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/plugins/custom/fullcalendar/fullcalendar.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <!--end::Page Vendors Styles-->
    <!--begin::Global Theme Styles(used by all pages)-->
    <link href="<?php echo e(asset("theme/metronic/plugins/global/plugins.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/plugins/custom/prismjs/prismjs.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/css/style.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("css/custom_form.css"), false); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Theme Styles-->
    <!--begin::Layout Themes(used by all pages)-->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset("images/logoGeelenc.png"), false); ?>">
    <link rel="manifest" href="<?php echo e(asset("images/favicon/manifest.json"), false); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!--end::Layout Themes-->
    <link rel="shortcut icon" href="<?php echo e(asset("theme/metronic/media/logos/favicon.ico"), false); ?>" />
</head>
<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/layouts/partials2/head.blade.php ENDPATH**/ ?>