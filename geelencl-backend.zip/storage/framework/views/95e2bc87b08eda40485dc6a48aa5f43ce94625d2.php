<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-secondary alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>    
    <strong><?php echo e($message, false); ?></strong>
</div>
<?php endif; ?>
<div class="card card-custom">
    <div class="card-header flex-wrap py-5">
        <div class="card-title">
        
            <h3 class="card-label">Perfil Empresarial</h3>
        </div>
        <div class="card-toolbar">

        </div>
      <hr>
    </div>
  <br>
    <h4 class="ml-8">Datos Generales</h4>
    <br>
    <div class="ml-8 mr-8">
      <form method="POST" enctype="multipart/form-data" action="<?php echo e(route ('saveCompanyProfile'), false); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Nombre comercial:</label>
            <input type="text" class="form-control" name="comercial_name" value="<?php echo e($company->comercial_name, false); ?>">
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Nombre de la empresa:</label>
            <input type="text" class="form-control" name="legal_name" value="<?php echo e($company->legal_name, false); ?>">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Representate legal:</label>
            <input type="text" class="form-control" name="administrador_name" value="<?php echo e($company->user->name, false); ?>">
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Ruc:</label>
            <input type="text" class="form-control" name="ruc" value="<?php echo e($company->ruc, false); ?>" maxlength="13">
          </div>

        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Correo:</label>
            <input type="email" class="form-control" name="email" value="<?php echo e($company->email, false); ?>" readonly>
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Estado:</label>
            <?php if($company->status == 'ACTIVE'): ?>
            <input type="text" class="form-control" name="estado" value="ACTIVA" readonly>
            <?php endif; ?>
            <?php if($company->status != 'ACTIVE'): ?>
            <input type="text" class="form-control" name="estado" value="INACTIVA" readonly>
            <?php endif; ?>

       
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputPassword4">Dirección 1:</label>
            <input type="text" class="form-control" name="direction" value="<?php echo e($company->direction, false); ?>">
          </div>

          <div class="form-group col-md-6">
            <label for="inputPassword4">Dirección 2:</label>
            <input type="text" class="form-control" name="direction2" value="<?php echo e($company->direction2, false); ?>">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Teléfono:</label>
            <input type="text" class="form-control" name="phoneNumber" value="<?php echo e($company->phone_number, false); ?>" maxlength="10">
          </div>
          <div class="form-group col-md-6">
            <label for="inputEmail4">Celular:</label>
            <input type="text" class="form-control" name="mobile_number" value="<?php echo e($company->mobile_number, false); ?>" maxlength="10">
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Guardar</button>
        <br>
        <br>
        <br>
 
      </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/companyProfile/index.blade.php ENDPATH**/ ?>