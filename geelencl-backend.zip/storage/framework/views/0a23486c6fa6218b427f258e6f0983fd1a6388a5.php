<?php echo Form::model($manual, array('id' => 'manual_form','class' => 'form-horizontal', 'method' => $method)); ?>

<?php echo Form::hidden('manual_id', $manual->id,['id'=>'manual_id']); ?>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <?php echo Form::label('name','* Nombre del manual:', array('class' => 'control-label col-md-12')); ?>

            <div class="col-md-12">
                <?php echo Form::text('name', $manual->name, array('class' => 'form-control', 'autocomplete' =>
                'off', 'placeholder' => 'ej. Manual de uso', 'maxlength' => '64')); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
        <?php echo Form::label('status','* Estado:', array('class' => 'control-label col-md-12')); ?>

        <div class="col-md-12">
            <?php echo Form::select('status', array( 'ACTIVE' => 'Activo', 'INACTIVE' => 'Inactivo'),$manual->status,array('class' => 'form-control') ); ?>

        </div>
        </div>
    </div>
    <div class="col-md-12">
        <div>
            <div class="form-group col-12">
                <?php echo Form::label('manual','* Archivo:', array('class' => 'control-label col-md-12')); ?>

                <br>
                
                    <?php if($manual->directory): ?>
                    <div class="col-12">
                    <?php
                        $dividido = explode("/", $manual->directory);
                        $nameFile = $dividido[2];
                    ?>
                    <a target="_blank" href= "<?php echo e($manual->directory, false); ?>"><?php echo e($nameFile, false); ?></a>
                    <iframe src="<?php echo e(url($manual->directory), false); ?>" style="width: 100%; height: 300px;"></iframe>
                </div>
                    <?php endif; ?>
                
                <div class="col-md-12">
                    <?php echo $__env->make('partials._dropzone_partial_files',[
                                  'title'=>"",
                                  'entity_id'=>$manual->id,
                                  'auto_process_queue'=>'no',
                                  'files'=>[],
                                  'handle_js_delete'=>'deleteFile'
                     ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
</div>
</div>
<?php echo Form::close(); ?>

<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/manual/loads/_form.blade.php ENDPATH**/ ?>