<?php echo Form::model($role, array('id' => 'role_form','class' => 'form-vertical', 'method' => $method)); ?>


<?php echo Form::hidden('role_id', $role->id,['id'=>'role_id']); ?>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <?php echo Form::label('name','* Nombre:', array('class' => 'control-label col-md-3')); ?>

            <div class="col-md-9">
                <?php echo Form::text('name', $role->name, array('class' => 'form-control', 'autocomplete' =>
                'off', 'placeholder' => 'ej. Operador', 'maxlength' => '64')); ?>

            </div>
        </div>
        <br>
        <br>
        <div class="form-group">
            <?php echo Form::label('name','* Guard:', array('class' => 'control-label col-md-3')); ?>

            <div class="col-md-9">
                <?php echo Form::select('guard_name',[''=>'Seleccione','web'=>"Web"], $role->guard_name, array('class' => 'form-control', 'autocomplete' =>
                'off', 'placeholder' => 'ej. web', 'maxlength' => '64')); ?>

            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<div class="row">
    <div class="col-md-12">
        <label class="col-md-3 control-label">Acciones permitidas</label>
        <div class="col-md-12">
            <table class="table table-bordered " id="table_permission">
                <thead>
                <tr>
                    <th style="width: 50px">
                        <div class="">
                            <input id="checkbox_all"
                                   value="1"
                                   class="magic-checkbox"
                                   type="checkbox">
                            <label for="checkbox_all"></label>
                        </div>
                    </th>
                    <th>Acción</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 50px">
                            <div class="">
                                <input id="checkbox_<?php echo e($permission->id, false); ?>" name="permissions[]"
                                       value="<?php echo e($permission->id, false); ?>"
                                       <?php echo e($role->hasPermissionTo($permission->name)?'checked="false"':'', false); ?> class="magic-checkbox checkbox-permission"
                                       type="checkbox">
                                <label for="checkbox_<?php echo e($permission->id, false); ?>"></label>
                            </div>
                        </td>
                        <td>
                            <?php echo e($permission->name, false); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/rbac/roles/loads/_form.blade.php ENDPATH**/ ?>