<?php
    $id = $id ?? uniqid("ss")
?>
<p id="<?php echo e($id, false); ?>_title">
    <?php echo e($title, false); ?>

</p>
<p id="<?php echo e($id, false); ?>_error" class="  text-danger  " style="display: none">
    <?php echo e($title, false); ?>. Es necesario subir al menos una imagen.
</p>
<div data-id="<?php echo e($id, false); ?>" class="dropzone <?php echo e($wrapper_class, false); ?> dropzone-file-area dz-clickable"
     data-max-width="<?php echo e($max_width, false); ?>"
     data-max-height="<?php echo e($max_height, false); ?>"
     data-image-parameter-id="<?php echo $entity_id; ?>"
     data-accepte-files="<?php echo $accepted_files; ?>"
     data-auto-process-queue="<?php echo e($auto_process_queue, false); ?>"
     <?php if(isset($attributes_additional)): ?>
         <?php $__currentLoopData = $attributes_additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php echo e($key, false); ?>="<?php echo e($value, false); ?>"
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
     style="width: 100%">
    <h5 class="text-center">Suelta tus imágenes aquí o haz clic para cargar</h5>
    <div class="dz-default dz-message">
        <span></span>
    </div>
    <?php if(isset($images) && count($images) > 0): ?>
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="<?php echo e($image['id'], false); ?>_wrapper_image" class="dz-preview image_exists dz-image-preview">
                <div class="dz-image">
                    <img data-dz-thumbnail="" alt="<?php echo e($image['file_name'], false); ?>"
                         src="<?php echo e($image['url'], false); ?>?h=120" width="120" height="120">
                </div>
                <div class="dz-details">
                    <div class="dz-filename">
                        <span data-dz-id="<?php echo e($image['id'], false); ?>"  data-dz-name="<?php echo e($image['file_name'], false); ?>"><?php echo e($image['file_name'], false); ?></span>
                    </div>
                </div>
                <div class="dz-success-mark">
                </div>
                <a class=" btn red btn-sm btn-block"
                   onclick="<?php echo e($handle_js_delete, false); ?>(<?php echo $image['id']; ?>)"
                   href="javascript:undefined;" style="cursor: pointer"
                   data-dz-remove="">Eliminar
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<br><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/partials/_dropzone_partial.blade.php ENDPATH**/ ?>