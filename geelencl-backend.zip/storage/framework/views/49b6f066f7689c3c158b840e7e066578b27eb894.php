<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'LANZA'), false); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset("images/favicon/apple-touch-icon.png"), false); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("images/favicon/favicon-32x32.png"), false); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset("images/favicon/favicon-16x16.png"), false); ?>">
    <link rel="manifest" href="<?php echo e(asset("images/favicon/site.webmanifest"), false); ?>">
    <link rel="mask-icon" href="<?php echo e(asset("images/favicon/safari-pinned-tab.svg"), false); ?>" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <!--STYLESHEET-->
    <!--=================================================-->

    <!--Open Sans Font [ OPTIONAL ]-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>


    <!--Bootstrap Stylesheet [ REQUIRED ]-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" />

    <!--Nifty Stylesheet [ REQUIRED ]-->
    <link href="<?php echo e(asset("nifty/css/nifty.min.css"), false); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('nifty/plugins/summernote/summernote.min.css'), false); ?>"
          rel="stylesheet">

    <!--Nifty Premium Icon [ DEMONSTRATION ]-->
    <link href="<?php echo e(asset("nifty/css/demo/nifty-demo-icons.min.css"), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("nifty/css/themes/type-b/theme-dust.css"), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("css/custom.css"), false); ?>" rel="stylesheet">


    <!--JAVASCRIPT-->
    <!--=================================================-->

    <!--Pace - Page Load Progress Par [OPTIONAL]-->
    <link href="<?php echo e(asset("nifty/plugins/pace/pace.min.css"), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset("nifty/plugins/magic-check/css/magic-check.min.css"), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('nifty/plugins/datatables/media/css/dataTables.bootstrap.css'), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('nifty/plugins/datatables/extensions/Responsive/css/responsive.dataTables.min.css'), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('nifty/plugins/datatables/extensions/Responsive/css/responsive.dataTables.min.css'), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('nifty/plugins/select2/css/select2.min.css'), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('js/plugins/bootstrap-toggle/css/bootstrap-toggle.css'), false); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('js/plugins/daterangepicker/daterangepicker.css'), false); ?>" rel="stylesheet"/>




    <?php echo $__env->yieldContent('additional-styles'); ?>
    <?php echo $__env->make('layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head><?php /**PATH C:\xampp\htdocs\geleenc_backend\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>