<?php
    $id = $id ?? uniqid("ss")
?>
<p id="<?php echo e($id, false); ?>_title">
    <?php echo e($title, false); ?>

</p>
<div data-id="<?php echo e($id, false); ?>"  class="m-dropzone dropzone m-dropzone--primary"
id="wrapper_file">
<br>
<h5 class="text-center">Suelta tus archivos aquí o haz clic para cargar</h5>
<div class="dz-default dz-message">
    <span></span>
</div>
    <div class="dz-default dz-message">
        <span></span>
    </div>
    <?php if(isset($files) && count($files) > 0): ?>
    <ul class="list-group">   
    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="<?php echo e($file['id'], false); ?>_wrapper_file" class="">
         <li class="list-group-item">     
                    <span class="badge badge-secondary badge-pill bandage-xs" style="margin-right: 0px;"><a class=" btn red btn-sm btn-block"
                        onclick="<?php echo e($handle_js_delete, false); ?>(<?php echo $file['id']; ?>)"
                        href="javascript:undefined;" style="cursor: pointer"
                        data-dz-remove="">x
                     </a></span> 
                    <a data-dz-id="<?php echo e($file['id'], false); ?>"  data-dz-name="<?php echo e($file['file_name'], false); ?>" target="_blank" href="<?php echo e($file['url'], false); ?>" style="cursor: pointer"><?php echo e($file['file_name'], false); ?> </a>

        </li>
    </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
</div>

<div class="hide" id="preview_file" style="display: none">
   
        <li class="list-group-item">
            <span class="badge badge-secondary badge-pill bandage-xs" style="margin-right: 0px;"><a class=" btn red btn-sm btn-block"
                href="javascript:undefined;" style="cursor: pointer"
                data-dz-remove="">x
             </a></span> 
            <a data-dz-id="<?php echo e($id, false); ?>"  data-dz-name="" target="_blank" href="" style="cursor: pointer"> </a>
        </li>
</div><?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/partials/_dropzone_partial_files.blade.php ENDPATH**/ ?>