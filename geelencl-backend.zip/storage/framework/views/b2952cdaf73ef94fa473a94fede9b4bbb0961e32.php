<?php $__env->startSection('content'); ?>
    <center><h1>Bienvenidos al administrador de GEELENCL</h1></center>
<?php $__env->stopSection(); ?>


<?php /**PATH C:\xampp\htdocs\geelencl-backend\resources\views/home.blade.php ENDPATH**/ ?>